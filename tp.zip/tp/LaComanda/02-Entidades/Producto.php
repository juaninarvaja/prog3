<?php   
    class Producto{
        
        public $id;
        public $nombre;
        public $rolEncargado;
        public $precio;                  
        
        public function __construct(){                
        }                         
    }
?>