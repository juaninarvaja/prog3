<?php   
    class Mesa{
        
        public $id;
        public $clave;
        public $estado_id; 
        public $cliente;              
        
        public function __construct(){                
        }                         
    }
?>