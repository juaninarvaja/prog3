<?php   
    class Usuario{
        
        public $id;
        public $nombre;
        public $rol;
        
        public function __construct(){                
        }                         
    }
?>