<?php
    include_once "./04-Acciones/UsuarioApi.php";
    include_once "./04-Acciones/ProductoApi.php";
    // include_once "./04-Acciones/MesaApi.php";
    // include_once "./04-Acciones/ComandaApi.php";
    // include_once "./04-Acciones/PedidoApi.php";
    include_once "./04-Acciones/AutenticacionApi.php";

    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;
	
	// header("Access-Control-Allow-Origin: *");
    // header("Content-Type: application/json; charset=UTF-8");

    require './vendor/autoload.php';

    $config['displayErrorDetails'] = true;
    $config['addContentLengthHeader'] = false;

    $app = new \Slim\App(['settings' => $config]);    
    
    // Login
    $app->post('/login', \AutenticacionApi::class . ':Login');

    // Usuario ABM
    $app->group('/usuario', function () {
        //$this->get('/{id}', \UsuarioApi::class . ':TraerUno');

        //$this->get('/', \UsuarioApi::class . ':TraerTodos')->add(\AutenticacionApi::class . ':ValidarSessionSocio');

        $this->post('/', \UsuarioApi::class . ':CargarUno');
        $this->post('/legajo', \UsuarioApi::class . ':ModificarUno')->add(\AutenticacionApi::class . ':ValidarSession');;
        //$this->post('/:legajo:', \UsuarioApi::class . ':CargarUno()');


        //$this->put('/', \UsuarioApi::class . ':ModificarUno');

        //$this->delete('/', \UsuarioApi::class . ':BorrarUno');  

    });//->add(\AutenticacionApi::class . ':ValidarSessionSocio');
    
    // Compra ABM
    $app->group('/materia', function () {
    //     $this->get('/{id}', \ProductoApi::class . ':TraerUno');

         //$this->get('/', \ProductoApi::class . ':TraerTodos')->add(\AutenticacionApi::class . ':ValidarSessionGetCompra');

         $this->post('/', \ProductoApi::class . ':CargarUno')->add(\AutenticacionApi::class . ':ValidarSessionAdmin');    

    //     $this->put('/', \ProductoApi::class . ':ModificarUno');

    //     $this->delete('/', \ProductoApi::class . ':BorrarUno'); 

    });//->add(\AutenticacionApi::class . ':ValidarSessionSocio');

    // Mesa ABM
    $app->group('/inscripcion', function () {
    //     $this->get('/', \MesaApi::class . ':TraerTodos');
    $this->post('/', \UsuarioApi::class . ':InscribirMateria')->add(\AutenticacionApi::class . ':ValidarSessionAlumno');
    //     $this->put('/', \MesaApi::class . ':ModificarUno');

     });//->add(\AutenticacionApi::class . ':ValidarSessionSocio');

    // // Comanda ABM
    // $app->group('/comandas', function () {
    //     $this->get('/{id}', \ComandaApi::class . ':TraerUno');

    //     $this->get('/', \ComandaApi::class . ':TraerTodos');

    //     $this->post('/', \ComandaApi::class . ':CargarUno');    

    //     $this->put('/', \ComandaApi::class . ':ModificarUno');

    //     $this->delete('/', \ComandaApi::class . ':BorrarUno'); 

    // })->add(\AutenticacionApi::class . ':ValidarSessionSocio');

    // // Pedido ABM
    // $app->group('/pedidos', function () {
    //     $this->get('/{rol}/{estado}', \PedidoApi::class . ':TraerPorRolYEstado');

    //     $this->post('/', \PedidoApi::class . ':CargarUno');    

    // })->add(\AutenticacionApi::class . ':ValidarSessionSocio');

    $app->run();
?>