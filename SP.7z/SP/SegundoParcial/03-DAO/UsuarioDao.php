<?php
    include_once "./02-Entidades/Identificadores.php";
    include_once "./02-Entidades/Usuario.php";
    include_once "./03-DAO/AccesoDatos.php";    
    include_once './05-Interfaces/IDaoABM.php';

    class UsuarioDAO{   
        const CLASSNAME = 'Usuario';
        
        #region Métodos
        // Guarda un elemento. Retorna el id guardado. (retorna false ahora).
        public static function Insert($elemento){
            $retorno = false;           
            
            $query = "INSERT INTO `usuario`(`nombre`, `clave`, `tipo`) ";
            $query .="VALUES (:nombre, :clave, :tipo)";                         
            
            try{
                $db = AccesoDatos::DameUnObjetoAcceso();                 
                $sentencia = $db->RetornarConsulta($query);
                $sentencia->bindValue(':nombre',  $elemento->nombre, PDO::PARAM_STR);
                $sentencia->bindValue(':clave',  $elemento->clave, PDO::PARAM_STR); 
                $sentencia->bindValue(':tipo',  $elemento->tipo, PDO::PARAM_STR);
                //var_dump($elemento);
                //$sentencia->bindValue(':sexo',  $elemento->sexo, PDO::PARAM_STR);                     
                
                $sentencia->execute(); 
                
                $retorno = true; //retorna true si no inserta también.                                                                          
            } catch (PDOException $e) {
                $retorno = false;
            }
        
            return $retorno;
        }

        // Consulta usuario 
        public static function ConsultarUsuario($elemento){
            $retorno = false;           
            $query = 
            "SELECT u.nombre, u.clave, u.tipo
            FROM usuario as u
            WHERE 
                u.nombre = :nombre AND
                u.clave = :clave AND
                u.tipo = :tipo ";
            
            try{
                $db = AccesoDatos::DameUnObjetoAcceso();               
                $sentencia = $db->RetornarConsulta($query); 
                $sentencia->bindValue(':nombre',  $elemento->nombre, PDO::PARAM_STR);
                $sentencia->bindValue(':clave',  $elemento->clave, PDO::PARAM_STR);
                $sentencia->bindValue(':tipo',  $elemento->tipo, PDO::PARAM_STR);
                //$sentencia->bindValue(':clave', $elemento->clave, PDO::PARAM_STR); 
                
                $sentencia->execute();                 
                $retorno = $sentencia->fetchObject(self::CLASSNAME);                                     
            } catch (PDOException $e) {
                $retorno = false;           
                
            }
            return $retorno;
        }

        #endregion

        #region Métodos Sin Usar
        
         //Traigo Elemento por id.
        public static function GetById($id){
            $retorno = null;                       
            
            $query = "SELECT `legajo`, `nombre`, `clave`, `tipo` FROM `usuario` WHERE `legajo` = :legajo";            

            try{
                $db = AccesoDatos::DameUnObjetoAcceso();               
                $sentencia = $db->RetornarConsulta($query); 
                $sentencia->bindValue(':legajo',  $id, PDO::PARAM_INT); 
                
                $sentencia->execute(); 
               
                
                $retorno = $sentencia->fetchObject(self::CLASSNAME); 
               // var_dump($retorno);                                   
                                                  
            } catch (PDOException $e) {
                $retorno = -1;                  
            }
            
            return $retorno;
        }   
        
        // Traigo todos los Elementos de la DB.
        
        public static function GetAll(){
            $retorno = array();           
            
            $query = "SELECT `id`, `nombre`,`perfil`,`sexo`, `clave` FROM `usuario`";
            
            try{
                $db = AccesoDatos::DameUnObjetoAcceso();               
                $sentencia = $db->RetornarConsulta($query); 
                
                $sentencia->execute(); 
                                
                $retorno = $sentencia->fetchAll(PDO::FETCH_CLASS, self::CLASSNAME);                                                                                      
            } catch (PDOException $e) {
                $retorno = -1;                 
            }
            
            return $retorno;
        }  
        
        
         // Modifica los datos de un elemento en la DB por el id.
         public static function Update($elemento, $legajo){
            $retorno = false;           
            
            $query = "UPDATE `usuario` SET `nombre`= :nombre, `tipo`= :tipo, `clave`=:clave WHERE `legajo`= :legajo";                        
            
            try{
                $db = AccesoDatos::DameUnObjetoAcceso();                 
                $sentencia = $db->RetornarConsulta($query); 
               // $sentencia->bindValue(':id',  $elemento->id, PDO::PARAM_INT);
                $sentencia->bindValue(':nombre',  $elemento->nombre, PDO::PARAM_STR);
                $sentencia->bindValue(':tipo',  $elemento->tipo, PDO::PARAM_STR);
                $sentencia->bindValue(':legajo',  $legajo, PDO::PARAM_INT); 
                $sentencia->bindValue(':clave',  $elemento->clave, PDO::PARAM_INT);                  
                
                $sentencia->execute(); 
                
                $retorno = true;                                  
            } catch (PDOException $e) {
                $retorno = false;
            }        
            
            return $retorno;
        }

        public static function UpdateUsuario($elemento, $legajo){
            $retorno = false;           
            
            $query = "UPDATE `usuario` SET `nombre`= :nombre, `tipo`= :tipo, `clave`=:clave ,`email`=:email WHERE `legajo`= :legajo";                        
            
            try{
                $db = AccesoDatos::DameUnObjetoAcceso();                 
                $sentencia = $db->RetornarConsulta($query); 
               // $sentencia->bindValue(':id',  $elemento->id, PDO::PARAM_INT);
                $sentencia->bindValue(':nombre',  $elemento->nombre, PDO::PARAM_STR);
                $sentencia->bindValue(':tipo',  $elemento->tipo, PDO::PARAM_STR);
                $sentencia->bindValue(':legajo',  $legajo, PDO::PARAM_INT); 
                $sentencia->bindValue(':clave',  $elemento->clave, PDO::PARAM_INT);  
                $sentencia->bindValue(':email',  $elemento->email, PDO::PARAM_STR);                 
                
                $sentencia->execute(); 
                
                $retorno = true;                                  
            } catch (PDOException $e) {
                $retorno = false;
            }        
            
            return $retorno;
        }


        public static function UpdateProfesor($elemento, $legajo){
            $retorno = false;           
            
            $query = "UPDATE `usuario` SET `nombre`= :nombre, `tipo`= :tipo, `clave`=:clave ,`email`=:email, `materiasD`=:materiasD WHERE `legajo`= :legajo";                        
            
            try{
                $db = AccesoDatos::DameUnObjetoAcceso();                 
                $sentencia = $db->RetornarConsulta($query); 
               // $sentencia->bindValue(':id',  $elemento->id, PDO::PARAM_INT);
                $sentencia->bindValue(':nombre',  $elemento->nombre, PDO::PARAM_STR);
                $sentencia->bindValue(':tipo',  $elemento->tipo, PDO::PARAM_STR);
                $sentencia->bindValue(':legajo',  $legajo, PDO::PARAM_INT); 
                $sentencia->bindValue(':clave',  $elemento->clave, PDO::PARAM_INT);  
                $sentencia->bindValue(':email',  $elemento->email, PDO::PARAM_STR);
                $sentencia->bindValue(':materiasD',  $elemento->materiasD, PDO::PARAM_STR);                  
                
                $sentencia->execute(); 
                
                $retorno = true;                                  
            } catch (PDOException $e) {
                $retorno = false;
            }        
            
            return $retorno;
        }
        public static function UpdateMaterias($materia, $nombre){
            $retorno = false;           
            
            $query = "UPDATE `usuario` SET `materiasI`= :materiasI WHERE `nombre`= :nombre";                        
            
            try{
                $db = AccesoDatos::DameUnObjetoAcceso();                 
                $sentencia = $db->RetornarConsulta($query); 
               // $sentencia->bindValue(':id',  $elemento->id, PDO::PARAM_INT);
                //$sentencia->bindValue(':nombre',  $elemento->nombre, PDO::PARAM_STR);
                //$sentencia->bindValue(':tipo',  $elemento->tipo, PDO::PARAM_STR);
                 $sentencia->bindValue(':nombre',  $nombre, PDO::PARAM_STR); 
                //$sentencia->bindValue(':clave',  $elemento->clave, PDO::PARAM_INT);  
                $sentencia->bindValue(':materiasI',  $materia, PDO::PARAM_INT);                 
                
                $sentencia->execute(); 
                
                $retorno = true;                                  
            } catch (PDOException $e) {
                $retorno = false;
            }        
            
            return $retorno;
        }
        public static function GetByNombre($nombre){
            $retorno = null;           
            
            $query = "SELECT legajo, nombre, tipo,clave,email,foto,materiasD,materiasI FROM `usuario` WHERE nombre=:nombre";
            
            try{
                $db = AccesoDatos::DameUnObjetoAcceso();               
                $sentencia = $db->RetornarConsulta($query); 
                $sentencia->bindValue(':nombre', $nombre, PDO::PARAM_STR); 
                
                $sentencia->execute(); 
                //var_dump($sentencia);                
                $retorno = $sentencia->fetchObject(self::CLASSNAME);                                                                                      
            } catch (PDOException $e) {
                $retorno = -1;                  
            }
            
            return $retorno;
        }   

/*
   

        // Borra el registro de un elemento en DB por el id.
        public static function Delete($id){
            $retorno = false;           
            $query = "DELETE FROM `usuario` WHERE id = :id";
            
            try {
                $db = AccesoDatos::DameUnObjetoAcceso(); 
                $sentencia = $db->RetornarConsulta($query);
                $sentencia->bindValue(':id',  $id, PDO::PARAM_INT);
                
                $sentencia->execute(); 
                
                $retorno = true;                                          
            } catch (PDOException $e) {
                $retorno = false;
            }
            
            return $retorno;
        }

        
        */
        #endregion

    }
?>