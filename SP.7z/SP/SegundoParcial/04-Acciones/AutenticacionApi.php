<?php
include_once "./03-DAO/UsuarioDAO.php";
require_once './02-Entidades/Usuario.php';
require_once './04-Acciones/ProductoApi.php';
require_once './04-Acciones/UsuarioApi.php';

use \Firebase\JWT\JWT;

class AutenticacionAPI{    
    private const CLAVE = "claveSecreta";

    // Evalua la existencia de la tupla nombre-clave y retorna token o false.
    public function Login($request, $response, $next) {
        $data = $request->getParsedBody(); 
        
        $elemento = new Usuario();
        //var_dump($elemento);
        $elemento->clave = isset($data["clave"])?$data["clave"]:null;
        //$elemento->clave = isset($data["clave"])?$data["clave"]:null; 
        //$elemento->tipo = isset($data["tipo"])?$data["tipo"]:null; 
        $legajo = $data["legajo"];
        //var_dump($legajo);
        $pass = $elemento->clave;
        $obj = UsuarioApi::TraerUnoporLegajo($legajo);
        $obj = json_decode($obj);
    //    var_dump($obj);
    //    var_dump($pass);
        //$elemento->perfil = isset($data["legajo"])?$data["legajo"]:null; 
       // $elemento->sexo = isset($data["sexo"])?$data["sexo"]:null; 

        if($obj != null)
        {
            if($obj->clave == $pass){
                //echo"entra";
                $token = $this->CrearToken($obj);
                //var_dump($token);
                $response->write($token);
            }
            else
            {
                $response->write("error,pass invalida"); 
            }
        }
        else{
            $response->write("error, no existe ese legaoj");
        }
        
        return $response;
    }

    // Valida el Token 
    public function ValidarSession($request, $response, $next) {        
        $data = getallheaders();        
        $token = isset($data["token"])?$data["token"]:"";

        $rol = $this->ValidarToken($token);
        
        if($rol != false){
            $response = $next($request, $response);            
            return $response;            
        }
        else{
            $response->write("inválido");
            return $response;
        }        
    }   

    // Valida el Token rol admin
    public function ValidarSessionAdmin($request, $response, $next) {        
        $data = getallheaders();        
        $token = isset($data["token"])?$data["token"]:"";

        $deco = $this->ValidarToken($token);

        //var_dump($deco);

        if($deco != null && $deco->rol == "admin"){
            $response = $next($request, $response);   
            echo "es admin y entra";         
            return $response;            
        }
        else{
            $response->write("hola");
            return $response;
        }        
    } 

        // Valida el Token rol admin
        public function ValidarSessionAlumno($request, $response, $next) {        
            $data = getallheaders();        
            $token = isset($data["token"])?$data["token"]:"";
    
            $deco = $this->ValidarToken($token);
           // var_dump($deco);
    
            if($deco != false && $deco->rol == "alumno"){
                $response = $next($request, $response);   
                //echo "es admin y entra";   ;      
                return $response;            
            }
            else{
                $response->write("no sos alumno");
                return $response;
            }        
        } 

            // Valida el Token rol Admin para el get
    public function ValidarSessionGetCompra($request, $response, $next) {
        $data = getallheaders();        
        $token = isset($data["token"])?$data["token"]:"";
        $deco = $this->ValidarToken($token);
        if($deco != false){ 
            // Agrego parametro id del usuario logeado. 
            $parametros = $request->getParsedBody(); 
            $parametros["rol"] = $deco->rol; 
            $request = $request->withParsedBody($parametros); 
            if( $parametros["rol"] == "admin")
            {
                $response = $next($request, $response);            
                return $response;    
            }
            else
            {
                $nombre = $deco->nombreUsu;
                //var_dump($nombre);
                 $obj = ProductoApi::TraerUnoPorNombre($nombre);
                $response->write($obj);
                return $response;
            }
        
        }
        else{
            $response->write("inválido");
            return $response;
        }     
          
    }   

    public function ObtenerNombreToken($token) {

        $deco = AutenticacionApi::ValidarToken($token);
        if($deco != false){ 
            //var_dump($deco);
            //$nombre = $deco->nombreUsu;
            //var_dump($nombre);
            return "";//$nombre;
        
        }
        else{
            return $null;
        }     
    }
    // Crea un token asociado al rol del usuario logueado.
    private function CrearToken($elemento){
        $token = false;
        $ahora = time();
        
        $rol = UsuarioDAO::ConsultarUsuario($elemento);
        //echo "el rol es";
        //var_dump($rol->perfil);
        if ($rol != null){        
            $payload = array(
                'iat' => $ahora,
                //'exp' => $ahora + (300),
                'app' => "API JN",
                'rol' => $rol->tipo,
                'nombre' => $rol->nombre
                //'nombreUsu' => $rol->nombre
            );
    
            $token = JWT::encode($payload, self::CLAVE);
            }
        
        return $token;
    } 

    // Verifica que el token sea vàlido y lo retorna como un objeto.
    public function ValidarToken($token){
        $valido = false;        

        if(empty($token) || $token === ""){
            //throw new Exception("Token vacio.");            
        }
        else
        {
            try
            {
                $decodificado = JWT::decode(
                    $token,
                    self::CLAVE,
                    ['HS256']
                );

                if($decodificado !== null && $decodificado != ""){
                    $valido = $decodificado;
                }
            }
            catch(Exception $ex)
            {                
                $valido = false;                
            }
        }
        
        return $valido;
    }
}
?>