<?php
    include_once "./03-DAO/UsuarioDAO.php";
    require_once './02-Entidades/Usuario.php';
    require_once './05-Interfaces/IAccionesABM.php';
    include_once "./03-DAO/ProductoDAO.php";
    require_once './04-Acciones/AutenticacionApi.php';

    class UsuarioApi{
        
        #region Métodos
        // Recibe datos en el body y pasa objeto al DAO para insertarlo. 
        public function CargarUno($request, $response, $args) {
            $data = $request->getParsedBody();        
            
            $elemento = new Usuario();
            $elemento->nombre = isset($data["nombre"])?$data["nombre"]:null;
            $elemento->clave = isset($data["clave"])?$data["clave"]:null;  
            $elemento->tipo = isset($data["tipo"])?$data["tipo"]:null; 
            //$elemento->sexo = isset($data["sexo"])?$data["sexo"]:null;   
            var_dump($elemento);                      
            if($elemento->tipo == "admin" || $elemento->tipo == "alumno"|| $elemento->tipo == "profesor")
            {
                if(UsuarioDAO::Insert($elemento)){
                    $JsonResponse = $response->withJson(true, 200);     
                }
                else{
                    $JsonResponse = $response->withJson(false, 400);                    
                }
            }
            else
            {
                return $response->write("error, tipo de usuario invalido");
            }
        }

        public function TraerUno($request, $response, $args) {
            $id = $args["id"];
            $obj = UsuarioDAO::GetById($id);            
            
            $JsonResponse = $response->withJson($obj, 200);        
            return $JsonResponse;
        }

        public function TraerUnoporLegajo($legajo) {
            //$id = $args["id"];
            $obj = UsuarioDAO::GetById($legajo);            
           // $obj = ProductoDAO::GetByNombre($nombre); 
            return json_encode($obj);   
 
        }



                // Retorna array json de todos los empleados.
       public function TraerTodos($request, $response, $args) {
            $lista = UsuarioDAO::GetAll();
            $strRespuesta;                                        
            if(count($lista)<1){
                $strRespuesta = "No existen registros.";
                }
            else{
                 for($i=0; $i<count($lista); $i++){
                  $strRespuesta[] = $lista[$i];
                 }                
                   }

                    $JsonResponse = $response->withJson($strRespuesta, 200);                    
                    return $JsonResponse; 
                 }



        
        // Crea un Elemento y se lo pasa al DAO para que haga el Update.
        public function ModificarUno($request, $response, $args) {
           
            $data = $request->getParsedBody(); 
            $legajo = isset($data["legajo"])?$data["legajo"]:null;  
            $elemento = UsuarioDAO::GetById($legajo);   
            
            if($elemento->tipo == "alumno"){
                $elemento->email =  isset($data["email"])?$data["email"]:null;

                if(UsuarioDAO::UpdateUsuario($elemento, $legajo)){
                    $JsonResponse = $response->withJson(true, 200); 
                    $response->write("modifico");
                }
                else{
                    $JsonResponse = $response->withJson(false, 400);                    
                }  
            }
            if($elemento->tipo == "profesor"){
                $elemento->email =  isset($data["email"])?$data["email"]:null;
                $elemento->materiasD = isset($data["materiasD"])?$data["materiasD"]:null;
               // var_dump($elemento);

                if(UsuarioDAO::UpdateProfesor($elemento, $legajo)){
                    $JsonResponse = $response->withJson(true, 200); 
                    $response->write("modifico");
                }
                else{
                    $JsonResponse = $response->withJson(false, 400);                    
                }  
            }   
            if($elemento->tipo == "admin"){
                $elemento->email =  isset($data["email"])?$data["email"]:null;
                $elemento->materiasD = isset($data["materiasD"])?$data["materiasD"]:null;
               // var_dump($elemento);

                if(UsuarioDAO::UpdateProfesor($elemento, $legajo)){
                    $JsonResponse = $response->withJson(true, 200); 
                    $response->write("modifico");
                }
                else{
                    $JsonResponse = $response->withJson(false, 400);                    
                }  
            } 
        }

        public function InscribirMateria($request, $response, $args)
        {
            $data = $request->getParsedBody(); 
            $id = isset($data["id"])?$data["id"]:null; 

            $data = getallheaders();        
            $token = isset($data["token"])?$data["token"]:"";
            $deco = AutenticacionApi::ValidarToken($token);
            $nameToken = $deco->nombre;

            $obj = ProductoDao::GetById($id);
           // $obj = ProductoDAO::GetByNombre($nombre); 
           
            //$objUsu = UsuarioDao::GetbyName();
            if($obj != null)
            {
                $cupo = (int)($obj->cupo);
                //var_dump($cupo);
                if($cupo > 0)
                {
                    UsuarioDao::UpdateMaterias($id,$nameToken);

                    //var_dump($obj);
                    $obj->cupo--;
                    //var_dump($obj);
                    $response->write("Inscripto de forma correcta");
                    ProductoDao::UpdateCupos($obj,$id);
                    //UsuarioDao::UpdateMateriasI()
                }
                else
                {
                    $response->write("no hay cupo");    
                }

            }
            else{
                $response->write("no es valido el id de esta materia"); 
            }
             
        }

        #endregion

        #region Sin Uso
        /*
        // Retorna json del empleado.
        public function TraerUno($request, $response, $args) {
            $id = $args["id"];
            $obj = UsuarioDAO::GetById($id);            
            
            $JsonResponse = $response->withJson($obj, 200);        
            return $JsonResponse;
        }




        // Elimina un Elemento por id.
        public function BorrarUno($request, $response, $args) {
            $data = $request->getParsedBody();        
            $id = isset($data["id"])?$data["id"]:null;
            
            if(UsuarioDAO::Delete($id)){
                $JsonResponse = $response->withJson(true, 200);     
            }
            else{
                $JsonResponse = $response->withJson(false, 400);                    
            }

            return $JsonResponse;
        }
        */
        #endregion
    }
?>