<?php   
    class Pedido{
        
        public $id;
        public $comanda;
        public $producto;
        public $estado;  
        public $tiempoInicio;  
        public $tiempoEstimado;  

        public function __construct(){                
        }                         
    }
?>