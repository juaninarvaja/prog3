<?php   
    class Comanda{
        
        public $id;
        public $codigo;
        public $mesa;
        public $foto;                  
        
        public function __construct(){                
        }                         
    }
?>