<?php   
    class Producto{
        
        //public $id;
        public $nombre;
        public $cuatrimestre;
        public $cupo;   
        //public $nombreUsu;               
        
        public function __construct(){                
        }                         
    }
?>