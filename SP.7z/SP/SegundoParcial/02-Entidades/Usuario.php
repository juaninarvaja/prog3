<?php   
    class Usuario{
                
        public $nombre;
        public $clave;
        public $tipo;
        public $email;
        public $materiasD;
        public $legajo;
        //public $perfil;                

        public function __construct(){                
        }                         
    }
?>