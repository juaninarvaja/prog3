<?php   
    class Mesa{
        
        public $id;
        public $clave;
        public $estado; 
        public $cliente;              
        
        public function __construct(){                
        }                         
    }
?>