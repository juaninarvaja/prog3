<?php   
    class Usuario{
        public $nombre;
        public $clave;
        public $sexo;
        public $perfil;

        public function __construct(){
            // $perfilValue = null;

            // if($perfil == null)
            // {
            //     $perfilValue = "usuario";

            //     $this->$nombre = $nombre;
            //     $this->$clave= $clave;
            //     $this->$sexo= $sexo;
            //     $this->$perfil= $perfilValue;
            // }
            // else
            // {
            //     $this->$nombre = $nombre;
            //     $this->$clave= $clave;
            //     $this->$sexo= $sexo;
            //     $this->$perfil= $perfil;
            // }

        }                         
    }
?>