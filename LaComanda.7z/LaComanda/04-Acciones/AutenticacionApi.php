<?php 
require_once './03-DAO/AutenticacionDAO.php';

class AutenticacionApi
{
    public static function Login($request, $response, $args)
    { 
        $token  = Autenticacion::Creartoken();
        $response->write($token);
        return $response;
    }

    public static function AutenticarToken($request, $response, $args)
    {
        $data = getallheaders();
        $token = isset($data ["token"])?$data["token"]:"";
        $valido = Autenticacion::ValidarToken($token);
        $response->write(json_encode($valido));
        return $response;
    }

}

?>