<?php   
    class Empleado{
        
        public $id;
        public $nombre;
        public $apellido;
        public $tarea_id;
        public $sector_id;  
        
        public function __construct(){                
        }                         
    }
?>