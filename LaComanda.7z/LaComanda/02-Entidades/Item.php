<?php   
    class Item{
        
        public $id;
        public $descripcion;
        public $sector_id;
        public $precio;                  
        
        public function __construct(){                
        }                         
    }
?>