<?php
    abstract class Tarea
    {
        const Bartender = 1;
        const Cervecero = 2;
        const Cocinero = 3;
        const Mozo = 4;
        const Socio = 5; 
    } 

    abstract class Sector
    {
        const BarraTragos = 1;
        const BarraCerveza = 2;
        const Cocina = 3;
        const CandyBar = 4;
        const Administracion = 5;  
        const Mesas = 6;
    } 
?>