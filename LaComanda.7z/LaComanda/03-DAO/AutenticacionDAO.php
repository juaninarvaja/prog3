<?php

use \Firebase\JWT\JWT;
class Autenticacion {
    public static function CrearToken()
    {   
        $clave = "miClave";
        $ahora = time();
        $payload = array(
            'iat' => $ahora,
            'exp' => $ahora +(30),
            //'data' = $data
            'app' => "API REST"
        );
        $token = JWT::encode($payload,$clave);
        return $token;
    }

    public static function ValidarToken($token)
    {
        //copiar
        return true;
        
    }

}


?>