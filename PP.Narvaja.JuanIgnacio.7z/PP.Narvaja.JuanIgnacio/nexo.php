<?php
 $tipo = $_SERVER['REQUEST_METHOD'];
   
 switch ($tipo) {
     
     case 'POST': 

        if(isset($_POST["caso"]))
         {
  
             $caso = $_POST["caso"];

             switch($caso){
                 case 'crearUsuario':
                
                     require_once "./Funciones/crearUsuario.php";
                     break;

                 case 'login':
                     require_once "./Funciones/login.php";
                     break;
                 
                 case 'cargarProducto':
                     require_once "./Funciones/cargarProducto.php";
                    break;
                case 'modificarProducto':
                    require_once "./Funciones/modificarProducto.php";
                   break;
                default: echo "POST INCORRECTO";
             }
         }
         break;
     case 'GET':
         
         if(isset($_GET["caso"]))
         {
             $caso = $_GET["caso"];
             switch($caso){
                 case 'listarUsuarios':
                     
                     require_once "./Funciones/listarUsuarios.php";
                     break;
                 
                 case 'listarProductos':
                     require_once "./Funciones/listarProductos.php";
                     break;
             default: echo "GET INCORRECTO";
             }
         }
         break;
 }
?>