<?php
include_once "./Clases/producto.php";
include_once "./Clases/usuario.php";

if(isset($_GET["criterio"]))
{
    $criterio = $_GET["criterio"];
    $valor = $_GET["valor"];
    switch($criterio){
        case 'producto':
        $arrayProductos = producto::leerArchivo();
        $flag = false;
        foreach($arrayProductos as $value)
        {
            if(strcasecmp($value["nombre"], $valor) == 0)
            {
                $id = $value["id"];
                $nombre= $value["nombre"];
                $precio = $value["precio"];
                $nombreUsuario = $value["nombreUsuario"];
                $imagen = $value["imagen"];
                echo "nombre producto: $nombre -- ID: $id -- precio: $precio --
                 Nombre Usuario: $nombreUsuario --- Ruta imagen: $imagen";
                    $flag = true;
                 
            }
        }
        if(!$flag)
        {
            echo "No existe producto $valor";
            return false;
        }
         break;
        


        case 'usuario':
                $arrayusuarioes = usuario::leerArchivo();
                $flag = false;
                foreach($arrayusuarioes as $value)
                {
                    if(strcasecmp($value["nombre"], $valor) == 0)
                    {
                        $nombre = $value["nombre"];
                        $clave = $value["clave"];
                            echo "nombre: $nombre --- clave: $clave";
                            $flag = true;
                         
                    }
                }
                if(!$flag)
                {
                    echo "No existe usuario $valor";
                    return false;
                }
            break;
        default: echo "criterio invalido";
    }

}
else
{
    foreach(Producto::leerArchivo() as $value)
    {
        $id = $value["id"];
        $nombre= $value["nombre"];
        $precio = $value["precio"];
        $nombreUsuario = $value["nombreUsuario"];
        $imagen = $value["imagen"];
        echo "nombre producto: $nombre -- ID: $id -- precio: $precio -- Nombre Usuario: $nombreUsuario --- Ruta imagen: $imagen <br>";
    }
}

?>