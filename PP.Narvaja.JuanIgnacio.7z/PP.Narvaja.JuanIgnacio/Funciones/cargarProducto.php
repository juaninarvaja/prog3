<?php
    echo "POST";

    include_once "./Clases/producto.php";
    include_once "./Funciones/agregarFoto.php";
  
    $urlFoto = guardarFoto($_FILES, $_POST);

    $miClase = new Producto($_POST["id"],$_POST["nombre"], $_POST["precio"], $urlFoto,$_POST["nombreUsuario"]);

    $miClase -> guardarArchivo();
?>