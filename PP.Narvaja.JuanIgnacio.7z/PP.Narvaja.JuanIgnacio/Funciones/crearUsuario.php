<?php
 
    include_once "./Clases/usuario.php";

        $nombreRecibido = $_POST["nombre"];

        $arrayusuarios = Usuario::leerArchivo();
        $flag = false;
        foreach($arrayusuarios as $value)
        {
            if(strcasecmp($value["nombre"], $nombreRecibido) == 0)
            {
                echo "ya existe un usuario con este nombre";
                $flag = true;
            }
        }
        if(!$flag)
        {
            $miClase = new Usuario($_POST["nombre"], $_POST["clave"]);

            $miClase -> guardarArchivo();
            echo "POST";

        }
?>