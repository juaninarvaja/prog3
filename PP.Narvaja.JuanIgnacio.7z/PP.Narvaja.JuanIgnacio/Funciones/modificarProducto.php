<?php  
include_once "./Clases/producto.php";
include_once "./Funciones/agregarFoto.php";

if(isset($_POST["id"]))
{
    $id = isset($_POST["id"])?$_POST["id"]:null;
    $nombre = isset($_POST["nombre"])?$_POST["nombre"]:null;
    $precio = isset($_POST["precio"])?$_POST["precio"]:null;
    $nombreUsuario = isset($_POST["nombreUsuario"])?$_POST["nombreUsuario"]:null;
    $foto = isset($_FILES["imagen"])?true:null;
    $arrayProductos = Producto::leerArchivo();
    $posicion = 0;
    foreach($arrayProductos as $value)
    {
      
        if($value["id"] == $id)
        {
            echo "entro";
            if($nombre == null)
                $nombre = $value["nombre"];
            if($nombreUsuario == null)
                $nombreUsuario = $value["nombreUsuario"];

            if($foto == true)
            {
                $foto = guardarFoto($_FILES, $_POST, $nombre, $nombreUsuario);
            } 
            else
            {
                $foto = $value["imagen"];
            }
            
            $newClass = new Producto($id,$nombre,$precio,$nombreUsuario);
            $arrayProductos[$posicion] = $newClass;
            break;
        }
        $posicion++;
    }
    Producto::guardarArray($arrayProductos);
}   
?>