<?php
include_once "./Clases/usuario.php";

$nombre = $_POST["nombre"];
$clave = $_POST["clave"];

$arrayusuarioes = usuario::leerArchivo();
$flag = false;
foreach($arrayusuarioes as $value)
{
    if(strcasecmp($value["nombre"], $nombre) == 0)
    {
        if(strcasecmp($value["clave"], $clave) == 0)
        {
            echo "TRUE";
            $flag = true;
            return true;
        }
    }
}
if(!$flag)
{
    echo "No existe usuario $nombre o la clave no es correcta";
}
?>