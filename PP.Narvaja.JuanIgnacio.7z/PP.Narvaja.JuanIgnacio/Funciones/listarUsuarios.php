<?php
include_once "./Clases/usuario.php";
$nombre = $_GET["nombre"];

$arrayusuarioes = usuario::leerArchivo();
$flag = false;
foreach($arrayusuarioes as $value)
{
    if(strcasecmp($value["nombre"], $nombre) == 0)
    {
            echo "TRUE";
            $flag = true;
           
    }
}
if(!$flag)
{
    echo "No existe usuario $nombre";
    return false;
}
?>