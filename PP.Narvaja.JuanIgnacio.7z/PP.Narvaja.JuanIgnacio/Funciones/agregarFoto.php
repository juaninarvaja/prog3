<?php 
function guardarFoto($file, $post = null, $nombreUsu = null, $nombre = null)
{
	$url = "./Fotos/";
	$urlBackup = "./backUpFotos/";
	$nameImagen = $file["imagen"]["name"];
	if($post != null)
	{
		$datoImagen = $post["nombre"]."-".$post["nombreUsuario"];
	}	
	else
	{
		$datoImagen = $nombre."-".$nombreUsu;
	}
	$explode = explode(".", $nameImagen);
	$tamaño = count($explode);

	$url .= $datoImagen;
	$url .= ".";
	$url .= $explode[$tamaño - 1];

	$hoy = date("m.d.y");
	$urlBackup .= $post["id"];
	$urlBackup .= "-".$hoy;
	$urlBackup .= ".";
	$urlBackup .= $explode[$tamaño - 1]; //la ext del artchivo

	if(!file_exists($url))
	{
		move_uploaded_file($_FILES["imagen"]["tmp_name"], $url);	
	}
	else
	{
		copy($url, $urlBackup);
		move_uploaded_file($_FILES["imagen"]["tmp_name"], $url);
	}
    
    return $url;
}
 ?>