<?php 
class Producto
{
public $id;
public $nombre;
public $precio;
public $imagen;
public $nombreUsuario;


 
 public function __construct($idR = null,$nom=null,$prec=null,$img=null,$nombreUsu=null)
        {
            $this->id = $idR;
            $this->nombre = $nom;
            $this->precio= $prec;
            $this->imagen= $img;
            $this->nombreUsuario= $nombreUsu;
        }

 public function ToJson()
 {
     return json_encode($this);
}

///guarda este objeto en el archivo
public function guardarArchivo()
{
    $archivo = "./Archivos/productos.txt";
    $actual = $this -> ToJson();
    
    if(file_exists($archivo))
    {
        $archivo = fopen("./Archivos/productos.txt", "a");		 
    }else
    {
        $archivo = fopen("./Archivos/productos.txt", "w");	 
    }
    
    $renglon = $actual.="\r\n";
    
    fwrite($archivo, $renglon); 		 
    fclose($archivo);
}

public static function leerArchivo()
{
    $archivo = "./Archivos/productos.txt";
    if(file_exists($archivo))
    {
        $file = @fopen($archivo, "r");
       
        $arrayProductos = array();
        $posicionArray = 0;
        while (($bufer = fgets($file, 4096)) !== false)
        {
            $arrayProductos[$posicionArray] = json_decode($bufer, true);
            $posicionArray++;
        }
           
           if (!feof($file)) 
        {
                echo "Error: fgets no llega la final()\n";
        }		
            
        fclose($file);
        return $arrayProductos;
    }   	
}

///guarda array completo en el archivo
public static function guardarArray($array)
{
    $archivo=fopen("./Archivos/productos.txt", "w"); 	
    foreach ($array as $value) 
    {
        $dato= json_encode($value);
         $dato.="\r\n";
        fwrite($archivo, $dato);
    }
    fclose($archivo);
}
}