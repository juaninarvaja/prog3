<?php 
class Usuario
{
//public $id;
public $nombre;
public $clave;


//public static $urlArchivoTexto = "./usuarios.txt";
 
 public function __construct($nom= null,$passw = null, $idR = null)
        {
            //$this->id = $idR;
            $this->nombre = $nom;
            $this->clave= $passw;
        }

 public function ToJson()
 {
     return json_encode($this);
}

///guarda este objeto en el archivo
public function guardarArchivo()
{
    $archivo = "./Archivos/usuarios.txt";
    $actual = $this -> ToJson();
    
    if(file_exists($archivo))
    {
        $archivo = fopen("./Archivos/usuarios.txt", "a");		 
    }else
    {
        $archivo = fopen("./Archivos/usuarios.txt", "w");	 
    }
    
    $renglon = $actual.="\r\n";
    
    fwrite($archivo, $renglon); 		 
    fclose($archivo);
}

public static function leerArchivo()
{
    $archivo = "./Archivos/usuarios.txt";
    if(file_exists($archivo))
    {
        $file = @fopen($archivo, "r");
       
        $arrayusuarios = array();
        $posicionArray = 0;
        while (($bufer = fgets($file, 4096)) !== false)
        {
            $arrayusuarios[$posicionArray] = json_decode($bufer, true);
            $posicionArray++;
        }
           
           if (!feof($file)) 
        {
                echo "Error: fgets no llega la final()\n";
        }		
            
        fclose($file);
        return $arrayusuarios;
    }   	
}

///guarda array completo en el archivo
public static function guardarArray($array)
{
    $archivo=fopen("./Archivos/usuarios.txt", "w"); 	
    foreach ($array as $value) 
    {
        $dato= json_encode($value);
         $dato.="\r\n";
        fwrite($archivo, $dato);
    }
    fclose($archivo);
}

}

?>